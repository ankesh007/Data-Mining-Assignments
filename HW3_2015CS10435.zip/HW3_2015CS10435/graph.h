#ifndef _GRAPH_H
#define	_GRAPH_H

#include <bits/stdc++.h>
using namespace std;

class graph {
public:
    vector<int> labels;    
    vector<vector<pair<int, int>>> adjList;
};
#endif

