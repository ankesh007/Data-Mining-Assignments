#ifndef EDGE_EVOLUTION_H
#define	EDGE_EVOLUTION_H

void edge_evolution();
#endif	
