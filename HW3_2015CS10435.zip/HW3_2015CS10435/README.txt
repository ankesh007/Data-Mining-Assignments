2015CS10435:Ankesh Gupta
2015CS10213:Anuj Dhawan
2015CS10208:Akash Mittal
We have referred to the paper: “GAIA: Graph Classification Using Evolutionary Computation” and have also referred to the online implementation of the same for mining discriminative features. We have used the same class structures after clarifying it with Sayan sir over an email.
