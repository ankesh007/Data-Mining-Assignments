import matplotlib.pyplot as plt
import sys
import random

outFile = open(sys.argv[1])
lines = outFile.readlines()
xpoints = []
ypoints = []
for line in lines:
	values = line.strip().split(" ")
	xpoints.append(float(values[0]))
	ypoints.append(float(values[1]))

outFile.close()

outFile = open(sys.argv[2])
lines = outFile.readlines()

pointX = []
pointY = []
cluster_number = -1
for line in lines:
	if(line[0]=='#'):
		pointX.append([])
		pointY.append([])
		cluster_number = cluster_number + 1
		continue

	index = int(line)
	pointX[cluster_number].append(xpoints[index])
	pointY[cluster_number].append(ypoints[index])




plt.xlim(-60,550)
plt.ylim(-60,220)

cluster_number = cluster_number + 1

for i in range(0,cluster_number):
	red_val = random.uniform(0, 1)
	blue_val = random.uniform(0, 1)
	green_val = random.uniform(0, 1)
	plt.scatter(pointX[i], pointY[i], color=(red_val, blue_val, green_val))

plt.show()
