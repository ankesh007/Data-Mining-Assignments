#!/bin/bash
if [ $1 = "-kmeans" ]
then
	./KMEANS $3 $2
elif [ $1 = "-dbscan" ]
then
    ./DBSCAN $2 $3 $4
elif [ $1 = "-optics" ]
then
    ./OPTICS $4 $3 $2
else
	echo "wrong format"
fi