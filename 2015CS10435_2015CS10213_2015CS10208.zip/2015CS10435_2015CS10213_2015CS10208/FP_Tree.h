#ifndef FP_TREE_H
#define FP_TREE_H

#include <bits/stdc++.h>

#define pb push_back
#define mp make_pair
#define x first
#define y second

using namespace std;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int,int> pii;
typedef vector<pii> vpii;
#endif